# my_minipack

A tiny learning package bundling two utilities from the Python ML Bootcamp.

## Modules

### `my_minipack.progress`

A progress-bar generator that wraps any iterable and prints a live progress bar.

```python
from time import sleep
from my_minipack.progress import ft_progress

for elem in ft_progress(range(1000)):
    sleep(0.005)
```

Output (live, updates in place):
```
ETA:  4.75s [ 50%][====================>                   ] 500/1000 | elapsed time 2.500000s
```

### `my_minipack.logger`

A `@log` decorator that records function name, user, and execution time to `machine.log`.

```python
from my_minipack.logger import log

@log
def my_function():
    ...

my_function()
# appends to machine.log:
# (vagarcia)Running:My Function          [ exec-time = 1.234 ms]
```

## Install

```bash
pip install ./dist/my_minipack-1.0.0-py3-none-any.whl
# or
pip install ./dist/my_minipack-1.0.0.tar.gz
```

## Build

```bash
bash build.sh
```

## License

GPLv3 — see [LICENSE.md](LICENSE.md).
